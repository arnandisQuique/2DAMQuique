package com.dam.quique; // Define el paquete de la clase.

import java.awt.event.ActionEvent; // Importa la clase ActionEvent para manejar eventos.
import java.awt.event.ActionListener; // Importa la interfaz ActionListener para escuchar eventos de acción.
import java.util.ArrayList; // Importa la clase ArrayList para manejar listas dinámicas.
import javax.swing.JFrame; // Importa la clase JFrame para crear ventanas.
import javax.swing.JOptionPane; // Importa la clase JOptionPane para mostrar cuadros de diálogo.

public class Controlador { // Declara la clase Controlador.

    private Vista vista; // Declara un objeto de tipo Vista para manejar la interfaz gráfica.
    private Modelo modelo; // Declara un objeto de tipo Modelo para manejar la lógica de datos.

    public Controlador(Vista vista, Modelo modelo) { // Constructor que recibe una vista y un modelo.
        this.vista = vista; // Asigna la vista proporcionada al atributo vista.
        this.modelo = modelo; // Asigna el modelo proporcionado al atributo modelo.
        Texto_Original(); // Llama al método para cargar el texto original.
        PalabraEncontrada(); // Llama al método para configurar la búsqueda de una palabra.
        ReemplazarTexto(); // Llama al método para configurar el reemplazo de texto.
    }

    public void Texto_Original() { // Método para cargar el texto original en la interfaz.
        vista.getTextAreaOriginal().setText(Modelo.leerEscribirTexto().toString()); // Obtiene el texto original del modelo y lo establece en el área de texto.
    }

    public void PalabraEncontrada() { // Método para configurar la búsqueda de una palabra.
        vista.getBtnBuscar().addActionListener(new ActionListener() { // Agrega un ActionListener al botón de búsqueda.
            public void actionPerformed(ActionEvent arg0) { // Método que se ejecuta al presionar el botón.
                String palabra = vista.getTextFieldBuscar().getText(); // Obtiene la palabra a buscar del campo de texto.
                int numVecesPalabra = modelo.encontrarPalabra(palabra); // Llama al método del modelo para contar cuántas veces aparece la palabra.
                JOptionPane.showMessageDialog(new JFrame(), numVecesPalabra + " veces"); // Muestra un cuadro de diálogo con el número de veces que se encontró la palabra.
            }
        });
    }

    public void ReemplazarTexto() { // Método para configurar el reemplazo de texto.
        vista.getBtnReemplazar().addActionListener(new ActionListener() { // Agrega un ActionListener al botón de reemplazo.
            @Override
            public void actionPerformed(ActionEvent e) { // Método que se ejecuta al presionar el botón.
                String palabraOriginal = vista.getTextFieldBuscar().getText(); // Obtiene la palabra original a buscar desde el campo de texto.
                String palabraNueva = vista.getTextFieldReemplazar().getText(); // Obtiene la nueva palabra que reemplazará a la original.
                ArrayList<String> textoModificado = Modelo.reemplazarTexto(palabraOriginal, palabraNueva); // Llama al método del modelo para reemplazar la palabra y obtiene el texto modificado.
                String textoComoString = String.join("\n", textoModificado); // Convierte el ArrayList de líneas en un único String, separando las líneas con saltos de línea.
                vista.getTextAreaModificado().setText(textoComoString); // Establece el texto modificado en el área de texto correspondiente de la vista.
            }
        });
    }
}
