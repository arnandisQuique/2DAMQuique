package com.dam.quique;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
	
		int menu =0;
		Boolean retorno = false;
		String dir="";
		
		do {
		System.out.println("Hola buenas, porfavor introduce un directorio con un subdirectorio interior y un fichero al menos");
		dir = teclado.nextLine();
		File directorio = new File(dir);

		
		
		if( directorio.exists ()) {
			retorno = true;

		
		
		
		System.out.println("Ahora que ya has introducido un directorio y este existe");
		System.out.println("Vas a ver lo sigiuente");
		System.out.println("");
		System.out.println("1) Mostrar el nombre, tipo , ubicación, ultima modificación y si está oculto");
		System.out.println("2) Crear una carpeta en el directorio actual");
		System.out.println("3) Crear un archivo en la carpeta creada");
		System.out.println("4) Eliminación de la carpeta y los archivos");
		System.out.println("5) REnombración de un archivo o carpeta que tu indiques");
		
		menu = teclado.nextInt();
		
		if( menu==1) {
			getInformacion(directorio);
		}
		if(menu==2) {
			crearCarpeta(directorio);
		}
		if(menu==3) {
			crearFichero(directorio);
		}
		if(menu==4) {
			eliminarFichero(directorio);
		}
		if(menu==5) {
			renombrar(directorio);
		}
		

		}
		else {
			System.out.println("El directorio no existe");
			retorno = false;
			System.out.println();

		
		}
       
		}while(retorno == false);
}
		
	public static void getInformacion(File directorio ) {
		System.out.println("");
		System.out.println("1): ");
		System.out.println(directorio.getName());
		
		System.out.println("");
		if(directorio.isFile()) {System.out.println("Archivo");}
		if(directorio.isDirectory()) {System.out.println("Carpeta"); }
		
		System.out.println("");
		String rutaAbsoluta = directorio.getAbsolutePath();
		System.out.println("La ubicación del archivo o directorio es: " + rutaAbsoluta);
		
		
		System.out.println("");
		Long s = directorio.lastModified();
		
		 if (s > 0) {
	            Date date = new Date(s);
	            System.out.println("La última modificación del archivo es: " + date);
	        } else {
	            System.out.println("El archivo no existe o no se puede acceder.");	
	        }
		 
		
		System.out.println("");
		if( directorio.isHidden()) {System.out.println("El archivo esta oculto");}
		else {System.out.println("EL archivo no esta oculto");}
		
		System.out.println("");
		System.out.println("El archivo pesa: " + directorio.length() + " Bytes");
		
		System.out.println();
		System.out.println(directorio.list().length);
		
		System.out.println();
		System.out.println("Espacio libre: "+ directorio.getFreeSpace());
		
		
		System.out.println();
		System.out.println("Espacio disponible: "+ directorio.getUsableSpace());
		

		System.out.println();
		System.out.println("Espacio total: "+ directorio.getTotalSpace());
		
		}
		
//--------------------------------------------------------------------------------------------------------------------
		public static void crearCarpeta(File directorio) {
			Scanner teclado = new Scanner (System.in);
		System.out.println("");
		System.out.println("2) :");
		
		String nuevo;

		File dir = directorio;
		
		System.out.println("Dime la nueva carpeta");
		nuevo = teclado.nextLine();
		String rutaTotal= dir+nuevo;
		
        File nuevoFile = new File(nuevo);

        
        if (nuevoFile.mkdir()) {
            System.out.println("Carpeta creada: " + nuevoFile.getAbsolutePath());
        } else {
            System.out.println("La carpeta ya existe o no se pudo crear.");
        }
        
		}
		
//--------------------------------------------------------------------------------------------------------------------
       public static void crearFichero(File directorio) {
    	   
		Scanner teclado = new Scanner (System.in);

        System.out.println("");
		System.out.println("3) :");
		
		
	    String rutaCompleta = String.valueOf(directorio) ;
		String nombreEntero="";
		String nombreFichero;
		String ext;
		
		
		System.out.println("Para crear un fichero, quiero que me digas el nombre");
		teclado.nextLine();
		nombreFichero=teclado.nextLine();
		
		System.out.println();
		System.out.println("Ahora dime la extension, ( que empiece por un punto)");
		ext=teclado.nextLine();
		
			

        String nombreCompleto = rutaCompleta+"\\" +  nombreFichero + ext;

        File archivo = new File(nombreCompleto);

				
        try {
            if (archivo.createNewFile()) {
                System.out.println("Fichero creado: " + archivo.getAbsolutePath());
            } else {
                System.out.println("El fichero ya existe.");
            }
        } catch (IOException e) {
            System.out.println("Ocurrió un error al crear el fichero: " + e.getMessage());
        }
		}
       
		
       
       public static void eliminarFichero(File directorio) {
		Scanner teclado = new Scanner (System.in);

       String fichero = "";
      
       System.out.println("Para eliminar un fichero, quiero que me digas el nombre:");
       fichero = teclado.nextLine();

       

       String rutaCompleta = String.valueOf(directorio) ;
       String nombreCompleto = rutaCompleta+ "\\" +fichero ;

       System.out.println("Intentando eliminar el fichero: " + nombreCompleto);
       
       File eliminar = new File(nombreCompleto);

       if (eliminar.exists()) {
           if (eliminar.delete()) {
               System.out.println("El fichero " + nombreCompleto + " ha sido eliminado.");
           } else {
               System.out.println("No se ha podido eliminar el fichero " + nombreCompleto + ".");
           }
       } else {
           System.out.println("El fichero " + nombreCompleto + " no existe.");
       }
      
	}
       	public static void renombrar(File directorio) {
       	Scanner teclado = new Scanner (System.in);
    	   String fichero = "";
    	      
           System.out.println("Para renombrar un fichero, quiero que me digas el nombre:");
           fichero = teclado.nextLine();
           String rutaCompleta = String.valueOf(directorio) ;
           String nombreCompleto = rutaCompleta + "\\" + fichero; ;

           File ficheroAntiguo = new File(nombreCompleto);
           
           
           
           System.out.println("Ahora dime el nuevo nombre");
           String nuevoNombre= teclado.nextLine();
           
           nombreCompleto = rutaCompleta + "\\" + nuevoNombre; ;

           System.out.println("Intentando renombrar el fichero: " + nombreCompleto);
           
           File renombrar = new File(nombreCompleto);

          
               if (ficheroAntiguo.renameTo(renombrar)) {
                   System.out.println("El fichero " + nombreCompleto + " ha sido renombrado.");
               } else {
                   System.out.println("No se ha podido renombrar el fichero " + nombreCompleto + ".");
               }   
    	   
       }
       

}
