package com.example.futbolistas;

import java.sql.*;
import java.util.ArrayList;

public class Conexion {

    private Connection conn;
    private String cadenaConexion = "jdbc:mysql://localhost:3306/futbol";
    private String nombreUsuario = "root";
    private String password = "";


    public Connection getConexion() {

        try {
            // Registra el controlador JDBC
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());

            // Establece la conexiÃ³n con la base de datos
            this.conn = DriverManager.getConnection(this.cadenaConexion, this.nombreUsuario, this.password);
            return this.conn;   // Retorna la conexiÃ³n establecida

        } catch (SQLException e) {
            e.printStackTrace();
            return null;    // Retorna null si ocurre un error durante la conexiÃ³n
        }
    }


    public void cerrarConexion() {
        try {
            this.conn.close();  // Cierra la conexiÃ³n
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


