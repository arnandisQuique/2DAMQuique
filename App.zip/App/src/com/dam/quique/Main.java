package com.dam.quique;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner teclado = new Scanner (System.in);
		
		sayHello();
		
		dimeNumeros();
		numerosEnteros();
		
		String[] companyeros = new String[6];
		companyeros[0]= "Quique";
		companyeros[1]= "Carles";
		companyeros[2]= "Alberto";
		companyeros[3] = "Daniela";
		companyeros[4] = "Gonzalo";
		companyeros[5]= "Pablo";		
		
		
	}
	
	public static void sayHello() {
		System.out.println("Actividad 1"); 
		System.out.println("Hola mundo!");
		System.out.println();
	}
	
	public static void dimeNumeros() {
		Scanner teclado = new Scanner(System.in);
		double suma=0;
		double dividir=0;
		double resultado=0;
		
		System.out.println("Actividad 2");
		System.out.println("Quiero que me digas dos numeros");
		System.out.println("Dime el primero:");
		double num1= teclado.nextDouble();
		System.out.println();
		
		System.out.println("Ahora dime el segundo:");
		double num2= teclado.nextDouble();
		System.out.println();
		
		
		//-----------------------------------------------------------------

		System.out.println("Me has dicho los números: " + num1 + " y " + num2);
		System.out.println("El intervalo es: ");
		if(num1<num2) {
			while(num1<=num2) {
				System.out.println(num1);
				num1++;				
			}
			
		}
		else {
			while(num1>=num2) {
				System.out.println(num2);
				num2++;					
			}
			
		}
		
		
		
		//-----------------------------------------------------------------
		System.out.println();		
		System.out.println("Ahora te voy a decir cuales son primos:");
		System.out.println("Vuelve a repetir los números");
		System.out.println("Dime el primero:");
		num1= teclado.nextDouble();
		System.out.println();
		
		System.out.println("Ahora dime el segundo:");
		num2= teclado.nextDouble();
		System.out.println();
		if(num1<num2) {
			while(num1<=num2) {
				if(num1/1!=1 && num1%num1==0) {
					System.out.println("Soy primo " + num1);
				}					
				num1++;
			}	
		}
		else {

			while(num1>=num2) {
				if(num2/1!=1 && num2%num2==0) {
					System.out.println("Soy primo " + num2);
				}
				num2++;		
			}
		}
		
		//-----------------------------------------------------------------

		System.out.println("Ahora voy a decirte la suma total de los números del intervalo");
		System.out.println();
		System.out.println("Vuelve a repetir los números");
		System.out.println("Dime el primero:");
		num1= teclado.nextDouble();
		System.out.println();
		
		System.out.println("Ahora dime el segundo:");
		num2= teclado.nextDouble();
		System.out.println();
		if(num1<num2) {
			while(num1<=num2) {
				suma = num1 + suma;
				num1++;
			}
		}
		
		else{
			while(num1>=num2) {
				suma = suma + num2;
				num2++;					
			}
		}
		System.out.println(suma);
		
	}
	
	public static void numerosEnteros() {
		Scanner teclado = new Scanner(System.in);

		ArrayList<Integer> numeros = new ArrayList<Integer>();
		int numero = 0;
		System.out.println();
		System.out.println("Ejercicio 3");
		System.out.println("Quiero que me digas números y los voy a almacenar en una lista");
		System.out.println("Cuando quieras parar de poner numeros pulsa la tecla X");
		String parar = "";
	
		do {
			
			System.out.println("Dime un número");
			numero=teclado.nextInt();
			numeros.add(numero);
			
			System.out.println("¿Quieres parar? ¿si o no?");
			teclado.nextLine();
			parar=teclado.nextLine();
			
			
			
		}while(parar=="si");
		
		
		System.out.println("Voy a ver que numero es el mas grande");
		for(int i = 0; i < numeros.size();i++) {
			
			Integer mayor = 0;
			
			mayor = numeros[i];
			
		}
		System.out.println("Adios");
	}

}
