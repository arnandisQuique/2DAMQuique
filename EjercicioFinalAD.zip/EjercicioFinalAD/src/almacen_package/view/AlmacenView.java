package almacen_package.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.ListSelectionModel;

import almacen_package.controller.AlmacenController;
import almacen_package.model.Almacen;
import almacen_package.model.Producte;

public class AlmacenView extends JFrame {
    
    private DefaultListModel<Producte> listModel;
    private JList<Producte> productList;
    private Almacen almacen;
    private AlmacenController almacenController;

    public AlmacenView() {
        // Inicializar el almacén y asignarlo correctamente
        this.almacen = new Almacen("productos.xml");
        almacenController = new AlmacenController(almacen, this);
        
        // Establecer el título de la ventana
        setTitle("Gestión de Almacén");
        
        // Establecer el tamaño de la ventana
        setSize(800, 600); // Ancho x Alto
        
        // Definir la operación de cierre de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Crear el modelo de lista y el JList
        listModel = new DefaultListModel<>();
        productList = new JList<>(listModel);
        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Crear un panel para los botones
        JPanel buttonPanel = new JPanel();
        JButton mostrarButton = new JButton("Mostrar Todos los Productos");
        JButton crearButton = new JButton("Crear Nuevo Producto");
        JButton actualizarButton = new JButton("Actualizar Producto");
        JButton borrarButton = new JButton("Borrar Producto");
        
        // Agregar acción al botón "Mostrar Todos los Productos"
        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarProductes();
            }
        });
        
        // Agregar acciones a los botones de crear, actualizar y borrar
        crearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearProducte();
            }
        });

        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarProducte();
            }
        });

        borrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarProducte();
            }
        });
        
        // Añadir los botones al panel
        buttonPanel.add(mostrarButton);
        buttonPanel.add(crearButton);
        buttonPanel.add(actualizarButton);
        buttonPanel.add(borrarButton);

        // Añadir componentes a la ventana
        add(new JScrollPane(productList), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    // Método para mostrar todos los productos en el JList
    public void mostrarProductes() {
        listModel.clear(); // Limpiar la lista existente
        for (Producte producte : almacen.recuperarTots()) {
            listModel.addElement(producte);
        }
    }
    
    // Métodos para crear, actualizar y borrar productos
    public void crearProducte() {
        String nombre = JOptionPane.showInputDialog(this, "Ingrese el nombre del producto:");
        String categoria = JOptionPane.showInputDialog(this, "Ingrese la categoría del producto:");
        String cantidadStr = JOptionPane.showInputDialog(this, "Ingrese la cantidad del producto:");
        String precioStr = JOptionPane.showInputDialog(this, "Ingrese el precio del producto:");
        String fechaEntrada = JOptionPane.showInputDialog(this, "Ingrese la fecha de entrada del producto:");

        try {
            int cantidad = Integer.parseInt(cantidadStr);
            double precio = Double.parseDouble(precioStr);

            Producte nuevoProducto = new Producte(nombre, categoria, cantidad, precio, fechaEntrada);
            int id = almacenController.crearProducte(nuevoProducto);
            JOptionPane.showMessageDialog(this, "Producto creado con ID: " + id);
            mostrarProductes();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error: Cantidad y precio deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void actualizarProducte() {
        Producte productoSeleccionado = productList.getSelectedValue();

        if (productoSeleccionado != null) {
            try {
                String nuevoNombre = JOptionPane.showInputDialog(this, "Nuevo nombre:", productoSeleccionado.getNom());
                String nuevaCategoria = JOptionPane.showInputDialog(this, "Nueva categoría:", productoSeleccionado.getCategoria());
                int nuevaCantidad = Integer.parseInt(JOptionPane.showInputDialog(this, "Nueva cantidad:", productoSeleccionado.getQuantitat()));
                double nuevoPrecio = Double.parseDouble(JOptionPane.showInputDialog(this, "Nuevo precio:", productoSeleccionado.getPreu()));
                String nuevaFechaEntrada = JOptionPane.showInputDialog(this, "Nueva fecha de entrada (yyyy-MM-dd):", productoSeleccionado.getDataEntrada());

                // Crear un nuevo objeto Producte con los nuevos valores
                Producte productoActualizado = new Producte(nuevoNombre, nuevaCategoria, nuevaCantidad, nuevoPrecio, nuevaFechaEntrada);

                // Llamar al método actualizarProducte con el ID y el nuevo objeto Producte
                boolean actualizado = almacenController.actualizarProducte(productoSeleccionado.getIdentificador(), productoActualizado);

                if (actualizado) {
                    JOptionPane.showMessageDialog(this, "Producto actualizado con éxito.");
                    mostrarProductes(); // Actualizar la lista
                } else {
                    JOptionPane.showMessageDialog(this, "Error al actualizar el producto.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Error: Cantidad y precio deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un producto para actualizar.");
        }
    }

    public void borrarProducte() {
        Producte productoSeleccionado = productList.getSelectedValue();

        if (productoSeleccionado != null) {
            int confirmacion = JOptionPane.showConfirmDialog(this, "¿Seguro que deseas eliminar el producto?", "Confirmación", JOptionPane.YES_NO_OPTION);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                // Verifica que almacenController no sea null
                if (almacenController != null && almacenController.borrarProducte(productoSeleccionado.getIdentificador())) {
                    JOptionPane.showMessageDialog(this, "Producto eliminado con éxito.");
                    mostrarProductes(); // Actualizar la lista
                } else {
                    JOptionPane.showMessageDialog(this, "Error al eliminar el producto.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un producto para eliminar.");
        }
    }


    public static void main(String[] args) {
        AlmacenView view = new AlmacenView();
        view.setVisible(true);
    }
}
