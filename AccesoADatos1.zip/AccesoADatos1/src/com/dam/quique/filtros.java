package com.dam.quique;

public class filtros extends EjerciciosFile {

	private String extension;

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public filtros(String extension) {
		super();
		this.extension = extension;
	}
	
	
	
	
	
}
