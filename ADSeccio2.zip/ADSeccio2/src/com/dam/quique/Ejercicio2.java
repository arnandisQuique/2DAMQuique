package com.dam.quique;

import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		String directorio = "";
		
		
		/*
		 . Introdueix una modificació en el programa anterior per tal que admeta un altre paràmetre
			d’entrada addicional que permeta especificar la velocitat a la qual es mostren els caràcters.
		 */
		
		System.out.println("Dime el directorio donde esté un archivo que tenga información para leer");
		directorio=teclado.nextLine();
		File file = new File(directorio);
		
		try {
			
			FileReader fr = new FileReader(file);
			int valor = fr.read();
			while(valor!=-1) {
				System.out.println((char)valor);
				valor = fr.read();
				Thread.sleep(1000);
			}
		fr.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		teclado.close();
	}

}
