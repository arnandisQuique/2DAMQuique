package com.example.pruebaxml;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class HelloController implements  Initializable{

    public Button buttonDelante;
    public Button buttonAtras;
    public Label labelId;
    public Label labelNombre;
    public Label labelEquipo;
    public Label labelAnyo;
    public Label labelPosicion;
    Integer position;

    ArrayList<FutbolistaPOJO> listaFutbolistas = new ArrayList<>();
    ApoyoXML datos = new ApoyoXML();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        position = 0; // Inicia en la primera posición de la lista.

        try {
            datos.LeerXML("Futbolistas.xml");

            // Verifica si la lista tiene datos antes de acceder.
            if (!datos.listyaFutbolistas.isEmpty()) {
                FutbolistaPOJO futbolistaInicial = datos.listyaFutbolistas.get(position);

                // Actualiza los Label con los datos del primer futbolista.
                labelId.setText(String.valueOf(futbolistaInicial.getId()));
                labelNombre.setText(futbolistaInicial.getNombre());
                labelEquipo.setText(futbolistaInicial.getEquipo());
                labelAnyo.setText(String.valueOf(futbolistaInicial.getAnyo()));
                labelPosicion.setText(futbolistaInicial.getPosicion());
            } else {
                System.out.println("La lista de futbolistas está vacía.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @FXML
    public void onDelanteButtonClick(ActionEvent actionEvent) {
        if (position < datos.listyaFutbolistas.size() - 1) {
            position++; // Avanza a la siguiente posición
            FutbolistaPOJO futbolista = datos.listyaFutbolistas.get(position);

            // Actualiza las etiquetas con los datos del jugador actual
            labelId.setText(String.valueOf(futbolista.getId()));
            labelNombre.setText(futbolista.getNombre());
            labelEquipo.setText(futbolista.getEquipo());
            labelAnyo.setText(String.valueOf(futbolista.getAnyo()));
            labelPosicion.setText(futbolista.getPosicion());
        } else {
            System.out.println("Ya estás en el último jugador.");
        }
    }

    public void onAtrasButtonClick(ActionEvent actionEvent) {
        if (position > 0) {
            position--; // Retrocede a la posición anterior
            FutbolistaPOJO futbolista = datos.listyaFutbolistas.get(position);

            // Actualiza las etiquetas con los datos del jugador actual
            labelId.setText(String.valueOf(futbolista.getId()));
            labelNombre.setText(futbolista.getNombre());
            labelEquipo.setText(futbolista.getEquipo());
            labelAnyo.setText(String.valueOf(futbolista.getAnyo()));
            labelPosicion.setText(futbolista.getPosicion());
        } else {
            System.out.println("Ya estás en el primer jugador.");
        }
    }


}