/**
 * 
 */
/**
 * 
 */
module EjercicioFinalAD {
	requires java.xml;
	requires java.desktop;
}