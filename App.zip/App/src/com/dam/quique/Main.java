package com.dam.quique;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner teclado = new Scanner (System.in);
		
		sayHello();
		
		
		
	}
	
	public static void sayHello() {
		System.out.println("Actividad 1"); 
		System.out.println("Hola mundo!");
		System.out.println();
	}
	

}
