package com.dam.quique;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		
		
		Scanner teclado = new Scanner(System.in);
		String directorio = "";
		
		
		System.out.println("Dime la ruta de un fichero");
		directorio = teclado.nextLine();
		File dir = new File(directorio);
		
		try {
			
			BufferedReader br = new BufferedReader(new FileReader(dir));
            String linea;

            while ((linea = br.readLine()) != null) {
            	System.out.println(linea);
            	Thread.sleep(1000);
            }
			
            br.close();
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		teclado.close();
		
	}

}
