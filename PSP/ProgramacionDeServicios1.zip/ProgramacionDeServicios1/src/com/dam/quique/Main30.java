package com.dam.quique;

public class Main30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
