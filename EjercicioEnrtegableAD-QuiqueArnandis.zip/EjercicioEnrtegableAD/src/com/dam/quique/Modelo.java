package com.dam.quique; // Define el paquete de la clase.

import java.io.BufferedReader; // Importa la clase BufferedReader para leer texto de manera eficiente.
import java.io.BufferedWriter; // Importa la clase BufferedWriter para escribir texto de manera eficiente.
import java.io.File; // Importa la clase File para manejar archivos.
import java.io.FileNotFoundException; // Importa la excepción para manejar archivos no encontrados.
import java.io.FileReader; // Importa la clase FileReader para leer archivos.
import java.io.FileWriter; // Importa la clase FileWriter para escribir en archivos.
import java.io.IOException; // Importa la excepción para manejar errores de entrada/salida.
import java.util.ArrayList; // Importa la clase ArrayList para manejar listas dinámicas.

public class Modelo { // Declara la clase Modelo.

    static String direccion = "texto.txt"; // Declara la dirección del archivo de texto.
    static File texto = new File(direccion); // Crea un objeto File con la dirección del archivo.
    static ArrayList<String> textoCompleto = new ArrayList<String>(); // Declara una lista para almacenar el texto completo del archivo.

    public Modelo() { // Constructor por defecto.
        
    }

    // Constructor que permite personalizar la dirección del archivo, el objeto File y el ArrayList.
    public Modelo(String direccion, File texto, ArrayList textoCompleto) {
        super();
        this.direccion = direccion; // Asigna la dirección proporcionada al atributo.
        this.texto = texto; // Asigna el objeto File proporcionado al atributo.
        this.textoCompleto = textoCompleto; // Asigna el ArrayList proporcionado al atributo.
    }

    // Método para leer el texto del archivo y devolverlo como un ArrayList de líneas.
    public static ArrayList<String> leerEscribirTexto() {        
        try {
            BufferedReader leer = new BufferedReader(new FileReader(texto)); // Crea un BufferedReader para leer el archivo.
            String linea; // Variable para almacenar cada línea del archivo.
            
            // Lee el archivo línea por línea.
            while ((linea = leer.readLine()) != null) {
                System.out.println(linea); // Imprime la línea leída en la consola.
                textoCompleto.add(linea); // Agrega la línea al ArrayList textoCompleto.
            }
            
            System.out.println("Copia completada."); // Indica que la lectura ha terminado.
        } catch (IOException e) { // Manejo de excepciones de entrada/salida.
            System.out.println("Ocurrió un error: " + e.getMessage()); // Imprime el mensaje de error.
            e.printStackTrace(); // Imprime el seguimiento de la pila del error.
        }

        return textoCompleto; // Devuelve el ArrayList con el texto completo.
    }   
    
    // Método para contar cuántas veces aparece una palabra en el archivo.
    public static int encontrarPalabra(String palabra) {
        int palabraRepetida = 0; // Contador para las repeticiones de la palabra.

        try {
            BufferedReader leer = new BufferedReader(new FileReader(texto)); // Crea un BufferedReader para leer el archivo.
            String linea; // Variable para almacenar cada línea del archivo.

            // Lee el archivo línea por línea.
            while ((linea = leer.readLine()) != null) {
                palabraRepetida += contarPalabrasEnLinea(linea, palabra); // Suma el número de veces que aparece la palabra en la línea.
            }

            leer.close(); // Cierra el BufferedReader.
        } catch (IOException e) { // Manejo de excepciones de entrada/salida.
            e.printStackTrace(); // Imprime el seguimiento de la pila del error.
        }

        return palabraRepetida; // Devuelve el número total de repeticiones de la palabra.
    }

    // Método privado que cuenta cuántas veces aparece una palabra en una línea específica.
    private static int contarPalabrasEnLinea(String linea, String palabra) {
        String[] palabras = linea.split("\\s+"); // Divide la línea en palabras usando espacios como delimitadores.
        int contador = 0; // Contador para las repeticiones de la palabra.

        // Recorre las palabras de la línea.
        for (String p : palabras) {
            if (p.equals(palabra)) { // Si la palabra coincide con la palabra buscada,
                contador++; // incrementa el contador.
            }
        }

        return contador; // Devuelve el número de veces que aparece la palabra en la línea.
    }
    
    // Método para reemplazar una palabra por otra en el texto del archivo.
    public static ArrayList<String> reemplazarTexto(String palabraBuscada, String palabraNueva) {
        ArrayList<String> nuevoTexto = new ArrayList<>(); // Lista para almacenar el nuevo texto con las palabras reemplazadas.
        
        try {
            BufferedReader leer = new BufferedReader(new FileReader(texto)); // Crea un BufferedReader para leer el archivo.
            String linea; // Variable para almacenar cada línea del archivo.
            
            // Lee el archivo línea por línea.
            while ((linea = leer.readLine()) != null) {
                // Reemplazar la palabra buscada por la palabra nueva en cada línea.
                linea = linea.replace(palabraBuscada, palabraNueva); // Realiza el reemplazo.
                nuevoTexto.add(linea); // Agrega la línea modificada a la lista nuevoTexto.
            }
            leer.close(); // Cierra el BufferedReader.
            
            // Sobrescribir el archivo con el nuevo texto.
            BufferedWriter escribir = new BufferedWriter(new FileWriter(texto, false)); // Crea un BufferedWriter para escribir en el archivo.
            
            // Escribe cada línea del nuevo texto en el archivo.
            for (String nuevaLinea : nuevoTexto) {
                escribir.write(nuevaLinea); // Escribe la línea en el archivo.
                escribir.newLine(); // Agrega un salto de línea.
            }
            escribir.close(); // Cierra el BufferedWriter.

        } catch (IOException e) { // Manejo de excepciones de entrada/salida.
            System.out.println("Error: " + e.getMessage()); // Imprime el mensaje de error.
            e.printStackTrace(); // Imprime el seguimiento de la pila del error.
        }
        
        return nuevoTexto; // Devuelve el nuevo texto modificado.
    }
}
