package com.example.futbolistas;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    public Button buttonDelante;
    public Button buttonAtras;

    public TextField textFieldId;
    public TextField textFieldNombre;
    public TextField TextFieldEquipo;
    public TextField textFieldAnyo;
    public TextField textFieldPosicion;

    private int position = 0; // Posición actual en la lista
    private ArrayList<FutbolistaPOJO> listaFutbolistas = new ArrayList<>();

    private ApoyoXML ax;
    private FutbolistasModel fm;
    int posicion;

    public void initialize(URL location, ResourceBundle resources) {

        fm = new FutbolistasModel();
        posicion = 0;

        FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
        textFieldId.setText(textFieldId.getText() + fp.getId());
        textFieldNombre.setText(fp.getNombre());
        TextFieldEquipo.setText(fp.getEquipo());
        textFieldAnyo.setText(String.valueOf(fp.getAnyo()));
        textFieldPosicion.setText(fp.getPosicion());
    }

    @FXML
    public void onDelanteButtonClick(ActionEvent actionEvent) throws ParserConfigurationException, IOException, SAXException {
        // Comprobar si la lista está vacía
        if (fm.listar_futbolistas().isEmpty()) {
            vaciarCampos(); // Vaciar los campos si no hay futbolistas
            Alert alertaNuevoFutbolista = new Alert(Alert.AlertType.INFORMATION, "No hay futbolistas en el registro. Introduce los datos para crear uno nuevo.");
            alertaNuevoFutbolista.show();

            // Verificar si los campos están llenos para crear un nuevo jugador
            if (!textFieldNombre.getText().isEmpty() && !TextFieldEquipo.getText().isEmpty() &&
                    !textFieldAnyo.getText().isEmpty() && !textFieldPosicion.getText().isEmpty()) {
                try {
                    // Generar un nuevo ID basado en el tamaño de la lista
                    int id = 1; // Si no hay futbolistas, el ID será 1
                    String nombre = textFieldNombre.getText();
                    String equipo = TextFieldEquipo.getText();
                    int anyo = Integer.parseInt(textFieldAnyo.getText());
                    String posicion = textFieldPosicion.getText();

                    // Añadir el nuevo futbolista al modelo
                    if (fm.anyadirFutbolistas(id, nombre, equipo, posicion, anyo)) {
                        Alert confirmacion = new Alert(Alert.AlertType.INFORMATION, "Nuevo futbolista añadido correctamente.");
                        confirmacion.show();

                        // Actualizar la lista y mostrar el jugador recién añadido
                        FutbolistaPOJO fp = fm.listar_futbolistas().get(0);
                        textFieldId.setText(String.valueOf(fp.getId()));
                        textFieldNombre.setText(fp.getNombre());
                        TextFieldEquipo.setText(fp.getEquipo());
                        textFieldAnyo.setText(String.valueOf(fp.getAnyo()));
                        textFieldPosicion.setText(fp.getPosicion());
                        int lugar = 1; // Avanzar a la siguiente posición
                    } else {
                        Alert error = new Alert(Alert.AlertType.ERROR, "Error al añadir el futbolista.");
                        error.show();
                    }

                } catch (NumberFormatException e) {
                    // Mostrar alerta si el año no es un número válido
                    Alert error = new Alert(Alert.AlertType.ERROR, "El campo 'Año' debe ser un número válido.");
                    error.show();
                }
            } else {
                // Alerta si los campos están vacíos
                Alert camposVacios = new Alert(Alert.AlertType.WARNING, "Todos los campos deben estar llenos para añadir un nuevo futbolista.");
                camposVacios.show();
            }
        } else {
            // Si hay futbolistas, mostrar el siguiente
            if (posicion < fm.listar_futbolistas().size()) {
                FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
                textFieldId.setText(String.valueOf(fp.getId()));
                textFieldNombre.setText(fp.getNombre());
                TextFieldEquipo.setText(fp.getEquipo());
                textFieldAnyo.setText(String.valueOf(fp.getAnyo()));
                textFieldPosicion.setText(fp.getPosicion());
                posicion++;
            } else {
                vaciarCampos();
                Alert a = new Alert(Alert.AlertType.INFORMATION, "No hay más registros.");
                a.show();
            }
        }
    }



    @FXML
    public void onAtrasButtonClick(ActionEvent actionEvent) {
        if (posicion <= 0) {
            // Si no hay futbolistas anteriores, vaciar los campos de texto
            vaciarCampos();
            Alert a = new Alert(Alert.AlertType.INFORMATION, "No hay registros previos.");
            a.show();
        } else {
            // Si hay futbolistas previos, mostrar el anterior
            posicion--;
            FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
            textFieldId.setText(String.valueOf(fp.getId()));
            textFieldNombre.setText(fp.getNombre());
            TextFieldEquipo.setText(fp.getEquipo());
            textFieldAnyo.setText(String.valueOf(fp.getAnyo()));
            textFieldPosicion.setText(fp.getPosicion());
        }
    }

    // Método para vaciar los campos de texto
    public void vaciarCampos() {
        textFieldId.setText("");
        textFieldNombre.setText("");
        TextFieldEquipo.setText("");
        textFieldAnyo.setText("");
        textFieldPosicion.setText("");
    }

    public void eliminado() {
        if (fm.listar_futbolistas().size() > 0) {
            fm.eliminar_futbolista(fm.listar_futbolistas().get(posicion).getId());
            posicion = 0;  // Reiniciar posición al eliminar
            if (fm.listar_futbolistas().size() > 0) {
                // Si hay más futbolistas después de eliminar, actualizar los campos
                FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
                textFieldId.setText(String.valueOf(fp.getId()));
                textFieldNombre.setText(fp.getNombre());
                TextFieldEquipo.setText(fp.getEquipo());
                textFieldAnyo.setText(String.valueOf(fp.getAnyo()));
                textFieldPosicion.setText(fp.getPosicion());
            } else {
                // Si no hay más futbolistas, vaciar los campos
                vaciarCampos();
            }
        } else {
            vaciarCampos();
            Alert a = new Alert(Alert.AlertType.INFORMATION, "No hay más futbolistas para eliminar.");
            a.show();
        }
    }

}
