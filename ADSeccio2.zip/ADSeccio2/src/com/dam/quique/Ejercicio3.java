package com.dam.quique;

import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Ejercicio3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String directorio = "";

        System.out.println("Dime el número de caracteres a mostrar por bloque:");
        int caracteresPorBloque = teclado.nextInt();
        teclado.nextLine(); 

        System.out.println("Dime el directorio donde esté un archivo que tenga información para leer:");
        directorio = teclado.nextLine();
        File file = new File(directorio);

        try {
            FileReader fr = new FileReader(file);
            char[] buffer = new char[caracteresPorBloque];
            int leidos = 0;

            while ((leidos = fr.read(buffer)) != -1) {
            	

                System.out.print(new String(buffer, 0, leidos));


                System.out.println("\n--- Presiona Enter para continuar ---");
                teclado.nextLine(); // Espera por la entrada del usuario
            }

            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        teclado.close();
    }
}
