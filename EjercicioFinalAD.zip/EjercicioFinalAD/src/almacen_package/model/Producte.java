package almacen_package.model;

public class Producte {

	private int identificador;
	private String nom;
	private String categoria;
	private int quantitat;
	private double preu;
	private String dataEntrada;
	
	
	
	public Producte(String nom, String categoria, int quantitat, double preu, String dataEntrada) {
		super();
		this.nom = nom;
		this.categoria = categoria;
		this.quantitat = quantitat;
		this.preu = preu;
		this.dataEntrada = dataEntrada;
	}


	public Producte(int identificador, String nom, String categoria, int quantitat, double preu, String dataEntrada) {
		super();
		this.identificador = identificador;
		this.nom = nom;
		this.categoria = categoria;
		this.quantitat = quantitat;
		this.preu = preu;
		this.dataEntrada = dataEntrada;
	}
	
	
	public Producte(){
		
	}


	
	
	public int getIdentificador() {
		return identificador;
	}


	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getCategoria() {
		return categoria;
	}


	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}


	public int getQuantitat() {
		return quantitat;
	}


	public void setQuantitat(int quantitat) {
		this.quantitat = quantitat;
	}


	public double getPreu() {
		return preu;
	}


	public void setPreu(double preu) {
		this.preu = preu;
	}


	public String getDataEntrada() {
		return dataEntrada;
	}


	public void setDataEntrada(String dataEntrada) {
		this.dataEntrada = dataEntrada;
	}


	@Override
	public String toString() {
		return "Producte [identificador=" + identificador + ", nom=" + nom + ", categoria=" + categoria + ", quantitat="
				+ quantitat + ", preu=" + preu + ", dataEntrada=" + dataEntrada + "]";
	}
	
	
	
	
}
 