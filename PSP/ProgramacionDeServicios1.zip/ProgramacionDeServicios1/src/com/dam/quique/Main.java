package com.dam.quique;

public class Main {

	public static void main(String[] args) {
		//Realiza un programa que a partir de dos números (introducidos en el código) muestre su
		//suma por pantalla.
		
		
		int num1 = 1;
		int num2 = 3;
		
		int suma ; 
		
		suma = num1+num2;
		
		
		System.out.println("EL resultado de la suma es : " + suma);
	}

}
