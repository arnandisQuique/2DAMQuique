package com.dam.quique;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner teclado = new Scanner (System.in);
		
		sayHello();
		
		
		
	}
	
	public static void sayHello() {
		System.out.println("Actividad 1"); 
		System.out.println("Hola mundo!");
		System.out.println();
	}
	
	public static void dimeNumeros() {
		Scanner teclado = new Scanner(System.in);
		double suma=0;
		double dividir=0;
		double resultado=0;
		
		System.out.println("Actividad 2");
		System.out.println("Quiero que me digas dos numeros");
		System.out.println("Dime el primero:");
		double num1= teclado.nextDouble();
		System.out.println();
		
		System.out.println("Ahora dime el segundo:");
		double num2= teclado.nextDouble();
		System.out.println();
		
		
		//-----------------------------------------------------------------

		System.out.println("Me has dicho los números: " + num1 + " y " + num2);
		System.out.println("El intervalo es: ");
		if(num1<num2) {
			while(num1<=num2) {
				System.out.println(num1);
				num1++;				
			}
			
		}
		else {
			while(num1>=num2) {
				System.out.println(num2);
				num2++;					
			}
			
		}
		
		
		
		//-----------------------------------------------------------------
		System.out.println();		
		System.out.println("Ahora te voy a decir cuales son primos:");
		System.out.println("Vuelve a repetir los números");
		System.out.println("Dime el primero:");
		num1= teclado.nextDouble();
		System.out.println();
		
		System.out.println("Ahora dime el segundo:");
		num2= teclado.nextDouble();
		System.out.println();
		if(num1<num2) {
			while(num1<=num2) {
				if(num1/1!=1 && num1%num1==0) {
					System.out.println("Soy primo " + num1);
				}					
				num1++;
			}	
		}
		else {

			while(num1>=num2) {
				if(num2/1!=1 && num2%num2==0) {
					System.out.println("Soy primo " + num2);
				}
				num2++;		
			}
		}
		
		//-----------------------------------------------------------------

		System.out.println("Ahora voy a decirte la suma total de los números del intervalo");
		System.out.println();
		System.out.println("Vuelve a repetir los números");
		System.out.println("Dime el primero:");
		num1= teclado.nextDouble();
		System.out.println();
		
		System.out.println("Ahora dime el segundo:");
		num2= teclado.nextDouble();
		System.out.println();
		if(num1<num2) {
			while(num1<=num2) {
				suma = num1 + suma;
				num1++;
			}
		}
		
		else{
			while(num1>=num2) {
				suma = suma + num2;
				num2++;					
			}
		}
		System.out.println(suma);
		
	}
	

}
