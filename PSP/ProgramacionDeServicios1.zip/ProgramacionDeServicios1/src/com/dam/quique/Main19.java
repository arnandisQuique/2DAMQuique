package com.dam.quique;

public class Main19 {

	public static void main(String[] args) {
		
		System.out.println("Tabla de caracteres ASCII:");

		for (int i = 32; i <= 126; i++) {
			System.out.println("ASCII " + i + ": " + (char)i);
    }
    }

}
