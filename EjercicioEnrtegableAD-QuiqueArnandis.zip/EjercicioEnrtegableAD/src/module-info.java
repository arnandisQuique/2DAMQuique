/**
 * 
 */
/**
 * 
 */
module EjercicioEnrtegableAD {
	requires java.desktop;
}