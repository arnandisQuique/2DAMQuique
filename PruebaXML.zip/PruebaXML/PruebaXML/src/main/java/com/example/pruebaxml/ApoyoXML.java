package com.example.pruebaxml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ApoyoXML {

    List<FutbolistaPOJO> listyaFutbolistas = new ArrayList<>();

    public void LeerXML(String path) throws SAXException, ParserConfigurationException, IOException {
        listyaFutbolistas.clear(); // Limpia la lista para evitar datos duplicados
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
        Document document = dbBuilder.parse(new File(path));

        Element raiz = document.getDocumentElement();
        System.out.println("Contenido XML " + raiz.getNodeName() + ":");
        NodeList nodeList = document.getElementsByTagName("futbolista");

        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) node;
                FutbolistaPOJO futbolista = new FutbolistaPOJO();
                futbolista.setId(Integer.parseInt(eElement.getElementsByTagName("id").item(0).getTextContent()));
                futbolista.setNombre(eElement.getElementsByTagName("nombre").item(0).getTextContent());
                futbolista.setEquipo(eElement.getElementsByTagName("equipo").item(0).getTextContent());
                futbolista.setAnyo(Integer.parseInt(eElement.getElementsByTagName("anyo").item(0).getTextContent()));
                futbolista.setPosicion(eElement.getElementsByTagName("posicion").item(0).getTextContent());
                listyaFutbolistas.add(futbolista);
                System.out.println("Futbolista añadido: " + futbolista.getNombre());
            }
        }

        System.out.println("Número total de futbolistas cargados: " + listyaFutbolistas.size());
    }


    public void EscribirXML(String path) throws TransformerException, ParserConfigurationException{
        // Crear un documento XML vacÃ­o
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        // Crear el elemento raÃ­z
        Element rootElement = doc.createElement("futbolistas");
        doc.appendChild(rootElement);

        for (FutbolistaPOJO futbolista: listyaFutbolistas ){


            // Agregar elementos y datos al documento
            Element childElement = doc.createElement("futbolista");
            childElement.setAttribute("id", String.valueOf(futbolista.getId()));

            // Agregamos bicicleta con ID=1 al root Bicicletas
            rootElement.appendChild(childElement);


            // Agregar elementos dentro de bicicleta -> marca
            Element nombre = doc.createElement("nombre");
            nombre.appendChild(doc.createTextNode(futbolista.getNombre()));
            childElement.appendChild(nombre);

            // Agregar elementos dentro de bicicleta -> modelo
            Element equipo = doc.createElement("equipo");
            equipo.appendChild(doc.createTextNode(futbolista.getEquipo()));
            childElement.appendChild(equipo);

            // Agregar elementos dentro de bicicleta -> anyo
            Element anyo = doc.createElement("anyo");
            anyo.appendChild(doc.createTextNode(String.valueOf(futbolista.getAnyo())));
            childElement.appendChild(anyo);


            Element posicion = doc.createElement("posicion");
            posicion.appendChild(doc.createTextNode(String.valueOf(futbolista.getPosicion())));
            childElement.appendChild(posicion);



        }
        // Guardar el documento XML en un archivo
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();

        // Formateamos el fichero XML
        Properties outputProperties = new Properties();

        // AquÃ­ marcamos que la tabulaciÃ³n debe ser de 4 espacios
        outputProperties.setProperty("{http://xml.apache.org/xslt}indent-amount", "4");

        // AquÃ­ marcamos que queremos la tabulaciÃ³n
        outputProperties.setProperty(OutputKeys.INDENT, "yes");

        // AquÃ­ marcamos que queremos la inicializaciÃ³n del archivo XML
        outputProperties.setProperty(OutputKeys.OMIT_XML_DECLARATION, "no");

        // Aplicamos las propiedades del fichero XML
        transformer.setOutputProperties(outputProperties);  // Opcional: dar formato al archivo

        // Especifica la ruta del archivo en el que deseas guardar el XML
        File xmlFile = new File(path);

        // Guarda el documento XML en el archivo especificado
        Result output = new StreamResult(xmlFile);
        transformer.transform(new DOMSource(doc), output);

        System.out.println("Archivo XML generado correctamente.");
    }

}
