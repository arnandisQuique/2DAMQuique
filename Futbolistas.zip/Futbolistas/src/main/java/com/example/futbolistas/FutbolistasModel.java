package com.example.futbolistas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class FutbolistasModel extends Conexion{

    public ArrayList<FutbolistaPOJO> listar_futbolistas(){
        ArrayList<FutbolistaPOJO> lista = new ArrayList<>();

        try {
            String sql = "Select * from jugadores";
            PreparedStatement ps = this.getConexion().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                FutbolistaPOJO p =  new FutbolistaPOJO(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
                lista.add(p);
            }

            rs.close();
            ps.close();
            this.cerrarConexion();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return lista;
    }

    public boolean eliminar_futbolista(int id){
        boolean resultado = false;

        try {
            String sql = "delete from jugadores where id = ?";
            PreparedStatement ps = this.getConexion().prepareStatement(sql);
            ps.setInt(1,id);
            ps.execute();
            resultado = true;

            ps.close();
            this.cerrarConexion();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return resultado;
    }

    public boolean anyadirFutbolistas(int id, String nombre, String equipo, String posicion, int anyo)  {
        boolean resultado = false;

        try {
            String sql = "INSERT INTO futbolistas (id, nombre, equipo, posicion, anio_nacimiento) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = this.getConexion().prepareStatement(sql);
            // Asignar los valores a la consulta
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.setString(3, equipo);
            ps.setString(4, posicion);
            ps.setInt(5, anyo);
            ps.execute();

            ps.executeUpdate();

        }catch (SQLException e) {
        e.printStackTrace();
        }

        return resultado;
    }
}
