package com.dam.quique;

import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		String directorio = "";
		
		
		/*
		 Escriu un programa que reba com a paràmetre d’entrada la ruta d’un fitxer, llija el seu
		 contingut i el mostre per pantalla caràcter a caràcter
		 */
		
		System.out.println("Dime el directorio donde esté un archivo que tenga información para leer");
		directorio=teclado.nextLine();
		File file = new File(directorio);
		
		try {
			
			FileReader fr = new FileReader(file);
			int valor = fr.read();
			while(valor!=-1) {
				System.out.println((char)valor);
				valor = fr.read();
			}
		fr.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		teclado.close();
	}

}
