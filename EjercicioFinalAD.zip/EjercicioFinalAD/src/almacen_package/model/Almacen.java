package almacen_package.model;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Almacen {
	Scanner teclado = new Scanner (System.in);

	 private ArrayList<Producte> productes = new ArrayList <Producte>();
	 	 
	 private String ruta="";
	 public Almacen(String ruta) {
	        this.ruta = ruta;
	        this.productes = new ArrayList<>();
	        cargarProductosDesdeXML();
	  }
	 private void cargarProductosDesdeXML() {
	        try {
	            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	            Document doc = dBuilder.parse(new File(ruta));

	            NodeList nodeList = doc.getElementsByTagName("producte");
	            for (int i = 0; i < nodeList.getLength(); i++) {
	                Element element = (Element) nodeList.item(i);
	                Producte p = new Producte();
	                p.setIdentificador(Integer.parseInt(element.getAttribute("id")));
	                p.setNom(element.getElementsByTagName("nom").item(0).getTextContent());
	                p.setCategoria(element.getElementsByTagName("categoria").item(0).getTextContent());
	                p.setQuantitat(Integer.parseInt(element.getElementsByTagName("quantitat").item(0).getTextContent()));
	                p.setPreu(Double.parseDouble(element.getElementsByTagName("preu").item(0).getTextContent()));
	                p.setDataEntrada(element.getElementsByTagName("dataEntrada").item(0).getTextContent());
	                productes.add(p);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	 
	public int crearProductes(Producte producte) {
		
		
		int idNuevo = productes.size()+1;
        producte.setIdentificador(idNuevo);
        System.out.println("El id nuevo es: " + idNuevo);
        
        
        productes.add(producte);
        System.out.println("Producto añadido: " + producte);

        try {
        	
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(new File(ruta));
	        
	        doc.getDocumentElement().normalize();
	        
	        Element raiz = doc.createElement("productes");
        
        for(Producte p : productes) {
        	
        	Element elemento = doc.createElement("producte");
        	elemento.setAttribute("id", String.valueOf(producte.getIdentificador()));
        	
        	Element nom = doc.createElement("nom");
        	nom.appendChild(doc.createTextNode(producte.getNom()));
        	elemento.appendChild(nom);
        	
        	
        	Element categoria = doc.createElement("categoria");
        	categoria.appendChild(doc.createTextNode(producte.getCategoria()));
        	elemento.appendChild(categoria);
        	
        	Element quantitat = doc.createElement("quantitat");
        	quantitat.appendChild(doc.createTextNode(String.valueOf(producte.getQuantitat())));
        	elemento.appendChild(quantitat);
        	
        	Element preu = doc.createElement("preu");
        	preu.appendChild(doc.createTextNode(String.valueOf(producte.getPreu())));
        	elemento.appendChild(preu);
        	
        	Element dataEntrada = doc.createElement("dataEntrada");
        	dataEntrada.appendChild(doc.createTextNode(String.valueOf(producte.getDataEntrada())));
        	elemento.appendChild(dataEntrada);
        	
            raiz.appendChild(elemento);
            
            
            TransformerFactory tf =TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
          	t.setOutputProperty(OutputKeys.INDENT,"yes");
        	DOMSource s = new DOMSource(doc);
        	StreamResult r = new StreamResult(new File ( ruta));
        	
        	
        	t.transform(s, r);
            System.out.println("Archivo XML guardado en: " + ruta);

           
        }
        
        
        
        }catch(Exception e) {
        	e.printStackTrace();
        }
        
	
		return idNuevo;
	}
	
	public Producte recuperarProducte(int identificador) {
		
        for(Producte p :productes) {
        	
        	if( p.getIdentificador()==identificador) {
        		return p;
        	}
        }
        System.out.println("No se encontró un producto con el identificador: " + identificador);
        return null; // Devuelve null si no se encuentra el producto
	}
	
	public void mostrarProducte(Producte producte) {
			
		System.out.println(producte.toString());
		
	}
	
	public boolean borrarProducte(int id) {
	    boolean encontrado = false;
	    
	    // Primero, elimina el producto de la lista 'productes'
	    for (int i = 0; i < productes.size(); i++) {
	        if (productes.get(i).getIdentificador() == id) {
	            productes.remove(i);
	            encontrado = true;
	            System.out.println("Producto con ID " + id + " eliminado de la lista.");
	            break;
	        }
	    }

	    try {
	        // Abre el archivo XML y elimina el nodo del producto si existe
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(new File(ruta));
	        doc.getDocumentElement().normalize();

	        NodeList productos = doc.getElementsByTagName("producte");

	        for (int i = 0; i < productos.getLength(); i++) {
	            Element p = (Element) productos.item(i);
	            int iden = Integer.parseInt(p.getAttribute("id"));

	            if (iden == id) {
	                p.getParentNode().removeChild(p);
	                encontrado = true;
	                System.out.println("Producto con ID " + id + " eliminado del archivo XML.");
	                break;
	            }
	        }

	        if (!encontrado) {
	            System.out.println("No se encontró un producto con el ID: " + id);
	        } else {
	            // Guarda los cambios en el archivo XML
	            TransformerFactory transformerFactory = TransformerFactory.newInstance();
	            Transformer transformer = transformerFactory.newTransformer();
	            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); // Para indentar el XML
	            DOMSource source = new DOMSource(doc);
	            StreamResult result = new StreamResult(new File(ruta));
	            transformer.transform(source, result);
	            System.out.println("Cambios guardados en el archivo XML.");
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
        return encontrado;

	    }
	
	public boolean actualizarProductes(int id, Producte producteActualitzat) {
	    boolean encontrado = false;

	    for (int i = 0; i < productes.size(); i++) {
	        Producte p = productes.get(i);
	        if (p.getIdentificador() == id) {
	            productes.set(i, producteActualitzat);
	            System.out.println("Producto actualizado: " + producteActualitzat);
	            encontrado = true;
	            break;
	        }
	    }

	    if (encontrado) {
	        try {
	            // Actualización en el archivo XML
	            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	            Document doc = dBuilder.parse(new File(ruta));
	            doc.getDocumentElement().normalize();

	            NodeList productos = doc.getElementsByTagName("producte");

	            for (int i = 0; i < productos.getLength(); i++) {
	                Element p = (Element) productos.item(i);
	                int iden = Integer.parseInt(p.getAttribute("id"));

	                if (iden == id) {
	                    // Actualizar los campos del producto en el XML
	                    p.getElementsByTagName("nom").item(0).setTextContent(producteActualitzat.getNom());
	                    p.getElementsByTagName("categoria").item(0).setTextContent(producteActualitzat.getCategoria());
	                    p.getElementsByTagName("quantitat").item(0).setTextContent(String.valueOf(producteActualitzat.getQuantitat()));
	                    p.getElementsByTagName("preu").item(0).setTextContent(String.valueOf(producteActualitzat.getPreu()));
	                    p.getElementsByTagName("dataEntrada").item(0).setTextContent(producteActualitzat.getDataEntrada());
	                    break;
	                }
	            }

	            // Guardar los cambios en el archivo XML
	            TransformerFactory transformerFactory = TransformerFactory.newInstance();
	            Transformer transformer = transformerFactory.newTransformer();
	            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); // Para indentar el XML
	            DOMSource source = new DOMSource(doc);
	            StreamResult result = new StreamResult(new File(ruta));
	            transformer.transform(source, result);
	            System.out.println("Cambios guardados en el archivo XML.");

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    } else {
	        System.out.println("No se encontró un producto con el ID: " + id + " para actualizar.");
	    }
	    
	    return encontrado;
	}
	
	
	private void guardarProducteXML(Producte producte) {
	    try {
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc;

	        // Comprobar si el archivo XML ya existe
	        File xmlFile = new File(ruta);
	        if (xmlFile.exists()) {
	            // Si el archivo existe, se carga
	            doc = dBuilder.parse(xmlFile);
	            doc.getDocumentElement().normalize();
	        } else {
	            // Si el archivo no existe, se crea un nuevo documento
	            doc = dBuilder.newDocument();
	            Element rootElement = doc.createElement("almacen");
	            doc.appendChild(rootElement);
	        }

	        // Crear el elemento de producto
	        Element productElement = doc.createElement("producte");
	        productElement.setAttribute("id", String.valueOf(producte.getIdentificador()));
	        productElement.appendChild(createElement(doc, "nom", producte.getNom()));
	        productElement.appendChild(createElement(doc, "categoria", producte.getCategoria()));
	        productElement.appendChild(createElement(doc, "quantitat", String.valueOf(producte.getQuantitat())));
	        productElement.appendChild(createElement(doc, "preu", String.valueOf(producte.getPreu())));
	        productElement.appendChild(createElement(doc, "dataEntrada", producte.getDataEntrada()));

	        // Agregar el producto al documento XML
	        doc.getDocumentElement().appendChild(productElement);

	        // Guardar los cambios en el archivo XML
	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transformer = transformerFactory.newTransformer();
	        transformer.setOutputProperty(OutputKeys.INDENT, "yes"); // Para indentar el XML
	        DOMSource source = new DOMSource(doc);
	        StreamResult result = new StreamResult(xmlFile);
	        transformer.transform(source, result);

	        System.out.println("Producto guardado en XML: " + producte.getNom());

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	private Element createElement(Document doc, String name, String value) {
        Element element = doc.createElement(name);
        element.appendChild(doc.createTextNode(value));
        return element;
    }

    public ArrayList<Producte> recuperarTots() {
        return productes;
    }
}

