package almacen_package.controller;

import java.util.ArrayList;

import almacen_package.model.Almacen;
import almacen_package.model.Producte;
import almacen_package.view.AlmacenView;

public class AlmacenController {

    private Almacen almacen;
    private AlmacenView almacenView;

    public AlmacenController(Almacen almacen, AlmacenView almacenView) {
        this.almacen = almacen;
        this.almacenView = almacenView;
    }

    // Método para crear un producto
    public int crearProducte(Producte producte) {
        return almacen.crearProductes(producte); // Llama al método de Almacen
    }

    // Método para recuperar un producto por su identificador
    public Producte recuperarProducte(int identificador) {
        return almacen.recuperarProducte(identificador); // Llama al método de Almacen
    }

    // Método para recuperar todos los productos
    public ArrayList<Producte> recuperarTots() {
        return almacen.recuperarTots(); // Llama al método de Almacen
    }

    // Método para actualizar un producto
    public boolean actualizarProducte(int id, Producte producte) {
        return almacen.actualizarProductes(id, producte); // Llama al método de Almacen
    }

    // Método para borrar un producto
    public boolean borrarProducte(int identificador) {
        return almacen.borrarProducte(identificador); // Llama al método de Almacen
    }
}
