package com.dam.quique;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) {
		
		
		Scanner teclado = new Scanner(System.in);
		String directorioLeer = "";
		String directorioEscribir = "";
		
		System.out.println("Dime la ruta de un fichero que quieres que leea");
		directorioLeer = teclado.nextLine();
		File dir = new File(directorioLeer);
		
		
		System.out.println("Ahora dime la ruta para escribir el ficheroº");
		directorioEscribir  = teclado.nextLine();
		File dirNuevo = new File(directorioEscribir);
				
		try {
			
			BufferedReader br = new BufferedReader(new FileReader(dir));
			BufferedWriter bw = new BufferedWriter(new FileWriter(dirNuevo));
            String linea;

            while ((linea = br.readLine()) != null) {
            	System.out.println(linea);
            	
            	bw.write(linea);
            	bw.newLine();
            	
            	Thread.sleep(1000);
            	
            }
			
            br.close();
			bw.close();
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		
		
		teclado.close();
		
	}

}
