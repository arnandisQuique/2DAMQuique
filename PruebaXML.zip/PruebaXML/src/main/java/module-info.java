module com.example.pruebaxml {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;
    requires java.logging;


    opens com.example.pruebaxml to javafx.fxml;
    exports com.example.pruebaxml;
}