package com.dam.quique;

import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		
		int mes ;
		int dia;
		int anio ;
		
		String[] frases = new String[12];
		Random r = new Random();
				
		frases[0] = "Tu mente está siempre un paso adelante, innovando y buscando lo diferente.";
		frases[1]= "Tu intuición te guía hacia los sueños más profundos y los sentimientos más sinceros.";
		frases[2]= "Tu valentía y energía arrolladora te llevan a conquistar cualquier desafío que se cruce en tu camino.";
		frases[3] = "La armonía y el equilibrio son tus guías, siempre buscando justicia y paz en tu entorno.";
		frases[4] ="Tu paciencia y perseverancia te hacen inquebrantable ante cualquier adversidad.";
		frases[5] = "Tu curiosidad y habilidad para adaptarte te permiten brillar en cualquier conversación.";
		frases[6] = "Tu corazón es tu brújula, siempre guiándote hacia la protección y el cuidado de quienes amas.";
		frases[7] = "Tu carisma natural y tu espíritu de liderazgo hacen que siempre estés en el centro de atención.";
		frases[8] = "Tu mente analítica y detallista te lleva a buscar la perfección en todo lo que haces.";
		frases[9] = "Tu intensidad y pasión profundas te hacen imparable en la búsqueda de la verdad.";
		frases[10] = "Tu espíritu aventurero y optimista te impulsa a explorar el mundo con una sonrisa.";
		frases[11] = "Tu disciplina y ambición te llevan a construir cimientos sólidos para alcanzar el éxito.";

		System.out.println("Hola buenas dime tu fecha de nacimiento y te digo el signo del zodiaco");
		
		System.out.println();
		System.out.println("Dime el mes");
		System.out.println("el orden es, Enero = 1 , Febrero = 2 ...");
		mes=teclado.nextInt();
		
		System.out.println();
		System.out.println("Ahora dime el dia");
		dia=teclado.nextInt();
		
		String resultado = obtenerSignoZodiaco(dia, mes);
		
		int random = r.nextInt(frases.length);

		System.out.println("Tu signo del zodiaco es: " + resultado);
		System.out.println("Y una frase motivadora: " + frases[random] );
		
		

	}


public static String obtenerSignoZodiaco(int dia, int mes) {
    if ((mes == 1 && dia >= 20) || (mes == 2 && dia <= 18)) {
        return "Acuario";
    } else if ((mes == 2 && dia >= 19) || (mes == 3 && dia <= 20)) {
        return "Piscis";
    } else if ((mes == 3 && dia >= 21) || (mes == 4 && dia <= 19)) {
        return "Aries";
    } else if ((mes == 4 && dia >= 20) || (mes == 5 && dia <= 20)) {
        return "Tauro";
    } else if ((mes == 5 && dia >= 21) || (mes == 6 && dia <= 20)) {
        return "Géminis";
    } else if ((mes == 6 && dia >= 21) || (mes == 7 && dia <= 22)) {
        return "Cáncer";
    } else if ((mes == 7 && dia >= 23) || (mes == 8 && dia <= 22)) {
        return "Leo";
    } else if ((mes == 8 && dia >= 23) || (mes == 9 && dia <= 22)) {
        return "Virgo";
    } else if ((mes == 9 && dia >= 23) || (mes == 10 && dia <= 22)) {
        return "Libra";
    } else if ((mes == 10 && dia >= 23) || (mes == 11 && dia <= 21)) {
        return "Escorpio";
    } else if ((mes == 11 && dia >= 22) || (mes == 12 && dia <= 21)) {
        return "Sagitario";
    } else if ((mes == 12 && dia >= 22) || (mes == 1 && dia <= 19)) {
        return "Capricornio";
    } else {
        return "Fecha no válida";
    }
}
}