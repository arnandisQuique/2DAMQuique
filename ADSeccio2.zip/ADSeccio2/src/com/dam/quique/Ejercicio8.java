package com.dam.quique;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class Ejercicio8 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		String directorio = "";
		String frases="";
		
		System.out.println("Dime donde quieres que escriba lo que me pongas por teclado");
		directorio=teclado.nextLine();
		File archivo = new File(directorio);
		
		
		try {
			
		BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true));
			
		
        System.out.println("Introduce cadenas de texto para escribir en el archivo (escribe 'exit' para finalizar):");
        
    	LocalDateTime fechaHoraActual = LocalDateTime.now();
    	DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    	bw.write("Archivo creado el: " + fechaHoraActual.format(formato));
        bw.write("");
        
        
        while (true) {
        	frases = teclado.nextLine();
        	
        	if (frases.equalsIgnoreCase("exit")) {
                break; 
            }        	
        	bw.write(frases);
            bw.newLine();
            
        }
        
        bw.close();
        System.out.println("El contenido se ha guardado correctamente");
        
        
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
		teclado.close();
	}

}
