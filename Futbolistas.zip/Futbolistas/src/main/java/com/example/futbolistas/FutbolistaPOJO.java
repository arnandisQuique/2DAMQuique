package com.example.futbolistas;

public class FutbolistaPOJO {


    private int id;
    private String nombre;
    private String equipo;
    private int anyo;
    private String posicion;

    public FutbolistaPOJO(){

    }
    public FutbolistaPOJO(int id, String nombre, String equipo, String posicion,int anyo) {
        this.id = id;
        this.nombre = nombre;
        this.equipo = equipo;
        this.anyo = anyo;
        this.posicion = posicion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public int getAnyo() {
        return anyo;
    }

    public void setAnyo(int anyo) {
        this.anyo = anyo;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }
}
