package com.dam.quique;

public class Main {

	public static void main(String[] args) {

		
		sayHello();
	}
	
	public static void sayHello() {
		
		System.out.println("Hola mundo!");
	}

}
