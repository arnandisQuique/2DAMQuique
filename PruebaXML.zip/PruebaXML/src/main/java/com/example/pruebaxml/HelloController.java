package com.example.pruebaxml;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class HelloController implements  Initializable{

    public Button buttonDelante;
    public Button buttonAtras;
    public Label labelId;
    public Label labelNombre;
    public Label labelEquipo;
    public Label labelAnyo;
    public Label labelPosicion;
    Integer position;


    ArrayList<FutbolistaPOJO> listaFutbolistas = new ArrayList<>();
    ApoyoXML datos = new ApoyoXML();



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        position = 0;


        try {
            datos.LeerXML("Futbolistas.xml");

            FutbolistaPOJO NotaInicial = new FutbolistaPOJO();
            labelId.setText(String.valueOf(NotaInicial.getId()));
            labelNombre.setText(NotaInicial.getNombre());
            labelEquipo.setText(NotaInicial.getEquipo());
            labelAnyo.setText(String.valueOf(NotaInicial.getAnyo()));
            labelPosicion.setText(NotaInicial.getPosicion());

        } catch (Exception e){
            e.printStackTrace();
        }

        try {
            datos.EscribirXML("Futbolistas.xml");
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    public void onDelanteButtonClick(ActionEvent actionEvent) {





    }

    public void onAtrasButtonClick(ActionEvent actionEvent) {
    }


}